IT Map 1.0.0
Minecraft 1.21.11 / Fabric Loader 0.18.2 / Java 21

Features in this build:
- Press M to open IT Map.
- Enter a numeric or text seed.
- Save Seed writes config/itmap-seed.txt in the Minecraft game directory.
- Load Saved reads the previously saved seed.

Not yet implemented:
- Rendering/generating the 50,000-block terrain map.
- Biome visualization and structure finder.
This build only saves and reloads the seed; it does not claim to generate a world map yet.

Build:
Run ./gradlew build (or gradlew.bat build on Windows) using Java 21.
